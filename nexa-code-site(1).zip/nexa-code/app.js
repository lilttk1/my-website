(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const body = document.body;
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = matchMedia('(hover: hover) and (pointer: fine)');

  /* theme inversion */
  const root = document.documentElement;
  const themeToggle = $('#themeToggle');
  const themeMeta = $('meta[name="theme-color"]');
  const storeTheme = { get(){ try { return localStorage.getItem('nexa-theme') || 'dark'; } catch { return 'dark'; } }, set(v){ try { localStorage.setItem('nexa-theme', v); } catch {} } };
  const applyTheme = (theme) => {
    root.dataset.theme = theme;
    if (themeMeta) themeMeta.setAttribute('content', theme === 'light' ? '#f5f5f5' : '#050505');
    if (themeToggle) themeToggle.setAttribute('aria-pressed', String(theme === 'light'));
  };
  applyTheme(storeTheme.get());
  if (themeToggle) themeToggle.addEventListener('click', () => {
    const next = root.dataset.theme === 'light' ? 'dark' : 'light';
    applyTheme(next); storeTheme.set(next);
  });

  /* header / nav */
  const header = $('#siteHeader');
  const menuToggle = $('#menuToggle');
  const mainNav = $('#mainNav');
  const setMenu = (open) => {
    header.classList.toggle('menu-open', open);
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    menuToggle.innerHTML = `<svg class="icon"><use href="#${open ? 'i-close' : 'i-menu'}"/></svg>`;
  };
  menuToggle.addEventListener('click', () => setMenu(!header.classList.contains('menu-open')));
  $$('a', mainNav).forEach(a => a.addEventListener('click', () => setMenu(false)));
  document.addEventListener('click', (e) => { if (header.classList.contains('menu-open') && !e.composedPath().includes(header)) setMenu(false); });

  const navSections = ['capabilities', 'work', 'approach', 'team', 'process', 'contact'].map(id => document.getElementById(id));
  const navLinks = $$('a', mainNav);
  const progressBar = $('#scrollProgress');
  let scrollTicking = false;
  const onScroll = () => {
    if (scrollTicking) return;
    scrollTicking = true;
    requestAnimationFrame(() => {
      header.classList.toggle('is-scrolled', scrollY > 24);
      const max = document.documentElement.scrollHeight - innerHeight;
      progressBar.style.width = `${max > 0 ? (scrollY / max) * 100 : 0}%`;
      const y = scrollY + innerHeight * 0.38;
      let current = '';
      navSections.forEach(sec => { if (sec.offsetTop <= y) current = sec.id; });
      navLinks.forEach(a => a.classList.toggle('is-active', a.getAttribute('href') === `#${current}`));
      scrollTicking = false;
    });
  };
  addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* reveal */
  const revealEls = $$('.reveal');
  if (reduceMotion.matches || !('IntersectionObserver' in window)) revealEls.forEach(el => el.classList.add('is-visible'));
  else {
    const io = new IntersectionObserver(entries => entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); } }), { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });
    revealEls.forEach(el => io.observe(el));
  }

  /* cursor / glow */
  const dot = $('#cursorDot'), ring = $('#cursorRing'), glow = $('#cursorGlow'), cursorLabel = $('#cursorLabel');
  const cursorSwitch = $('#cursorSwitch'), glowSwitch = $('#glowSwitch');
  const effectsToggle = $('#effectsToggle'), effectsPanel = $('#effectsPanel');
  const store = { get(k, f) { try { const v = localStorage.getItem(k); return v === null ? f : v === '1'; } catch { return f; } }, set(k, v) { try { localStorage.setItem(k, v ? '1' : '0'); } catch {} } };
  let cursorEnabled = store.get('nexa-cursor', true), glowEnabled = store.get('nexa-glow', !reduceMotion.matches);
  let mx = innerWidth / 2, my = innerHeight / 2, dx = mx, dy = my, rx = mx, ry = my, gx = mx, gy = my, seen = false, raf = null;
  const applyEffects = () => {
    const active = finePointer.matches;
    body.classList.toggle('custom-cursor', active && cursorEnabled);
    body.classList.toggle('glow-on', active && glowEnabled && !reduceMotion.matches);
    cursorSwitch.checked = cursorEnabled; glowSwitch.checked = glowEnabled;
    if (!active || (!cursorEnabled && !glowEnabled)) { body.classList.remove('cursor-ready'); if (raf) cancelAnimationFrame(raf); raf = null; }
    else if (seen && !raf) raf = requestAnimationFrame(tick);
  };
  const tick = () => {
    dx += (mx - dx) * 0.5; dy += (my - dy) * 0.5;
    rx += (mx - rx) * 0.32; ry += (my - ry) * 0.32;
    gx += (mx - gx) * 0.12; gy += (my - gy) * 0.12;
    dot.style.transform = `translate3d(${dx}px,${dy}px,0)`;
    ring.style.transform = `translate3d(${rx}px,${ry}px,0)`;
    glow.style.transform = `translate3d(${gx}px,${gy}px,0)`;
    raf = requestAnimationFrame(tick);
  };
  addEventListener('pointermove', e => {
    if (e.pointerType === 'touch' || !finePointer.matches) return;
    mx = e.clientX; my = e.clientY;
    if (!seen) { dx = mx; dy = my; rx = mx; ry = my; gx = mx; gy = my; seen = true; }
    if (cursorEnabled || glowEnabled) { body.classList.add('cursor-ready'); if (!raf) raf = requestAnimationFrame(tick); }
  }, { passive: true });
  document.addEventListener('mouseleave', () => body.classList.remove('cursor-ready'));
  addEventListener('blur', () => body.classList.remove('cursor-ready'));
  addEventListener('pointerdown', e => {
    if (e.pointerType === 'touch' || !finePointer.matches) return;
    // В момент клика фиксируем кружок точно под указателем, чтобы он не «догонял» мышь.
    mx = e.clientX; my = e.clientY;
    dx = mx; dy = my; rx = mx; ry = my;
    ring.classList.add('is-down');
  });
  addEventListener('pointerup', () => ring.classList.remove('is-down'));
  addEventListener('pointercancel', () => ring.classList.remove('is-down'));
  const hoverLabel = (el) => {
    if (el.closest('[data-case]')) return 'View';
    if (el.closest('[data-member]')) return 'Info';
    if (el.closest('a,button,select,input,textarea,summary')) return '';
    return null;
  };
  document.addEventListener('mouseover', e => {
    const label = hoverLabel(e.target);
    if (label !== null) { ring.classList.add('is-hover'); cursorLabel.textContent = label; }
    else { ring.classList.remove('is-hover'); cursorLabel.textContent = ''; }
  });
  cursorSwitch.addEventListener('change', () => { cursorEnabled = cursorSwitch.checked; store.set('nexa-cursor', cursorEnabled); applyEffects(); });
  glowSwitch.addEventListener('change', () => { glowEnabled = glowSwitch.checked; store.set('nexa-glow', glowEnabled); applyEffects(); });
  finePointer.addEventListener('change', applyEffects); reduceMotion.addEventListener('change', applyEffects); applyEffects();
  const setEffectsPanel = open => { effectsPanel.hidden = !open; effectsToggle.setAttribute('aria-expanded', String(open)); };
  effectsToggle.addEventListener('click', () => setEffectsPanel(effectsPanel.hidden));
  document.addEventListener('click', e => { if (!e.target.closest('.effects-wrap')) setEffectsPanel(false); });

  /* capability cards: pointer-tracked highlight */
  if (finePointer.matches && !reduceMotion.matches) $$('.cap-card').forEach(card => {
    card.addEventListener('pointermove', e => {
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', `${e.clientX - r.left}px`);
      card.style.setProperty('--my', `${e.clientY - r.top}px`);
    }, { passive: true });
    card.addEventListener('pointerleave', () => { card.style.removeProperty('--mx'); card.style.removeProperty('--my'); });
  });

  /* lab: in the single-file build the page lives in #labSource and is opened from a Blob */
  const labSource = $('#labSource');
  if (labSource) {
    let labUrl = null;
    const buildLabUrl = () => {
      if (labUrl) return labUrl;
      const bytes = Uint8Array.from(atob(labSource.textContent.trim()), c => c.charCodeAt(0));
      const html = new TextDecoder().decode(bytes);
      labUrl = URL.createObjectURL(new Blob([html], { type: 'text/html;charset=utf-8' }));
      return labUrl;
    };
    const openLab = () => {
      let url;
      try { url = buildLabUrl(); } catch { showToast('Не удалось открыть лабораторию', 'error'); return null; }
      // NB: passing 'noopener' here would make window.open return null even on
      // success, so sever the link manually instead of relying on the feature string.
      const win = window.open(url, '_blank');
      if (!win) { showLabOverlay(url); return null; }
      try { win.opener = null; } catch {}
      return win;
    };
    const showLabOverlay = (url) => {
      let overlay = $('#labOverlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'labOverlay';
        overlay.className = 'lab-overlay';
        overlay.innerHTML = '<div class="lab-overlay-bar"><span>TORQUE LAB · демо-стенд Nexa Code</span>'
          + '<button type="button" class="button button-small button-ghost" data-close-lab>Закрыть ✕</button></div>'
          + '<iframe class="lab-overlay-frame" title="TORQUE LAB — демо-стенд Nexa Code"></iframe>';
        document.body.appendChild(overlay);
        overlay.querySelector('[data-close-lab]').addEventListener('click', () => {
          overlay.classList.remove('is-open');
          body.style.removeProperty('overflow');
        });
        addEventListener('keydown', e => {
          if (e.key === 'Escape' && overlay.classList.contains('is-open')) {
            overlay.classList.remove('is-open');
            body.style.removeProperty('overflow');
          }
        });
      }
      const frame = overlay.querySelector('iframe');
      if (frame.src !== url) frame.src = url;
      overlay.classList.add('is-open');
      body.style.overflow = 'hidden';
    };
    $$('[data-lab-link]').forEach(link => {
      link.addEventListener('click', e => { e.preventDefault(); openLab(); });
    });
  }

  /* magnetic */
  if (finePointer.matches && !reduceMotion.matches) $$('.magnetic').forEach(el => {
    el.addEventListener('pointermove', e => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left - r.width / 2) * 0.18;
      const y = (e.clientY - r.top - r.height / 2) * 0.28;
      el.style.transform = `translate(${x}px,${y}px)`;
    });
    el.addEventListener('pointerleave', () => { el.style.transform = ''; });
  });

  /* hero canvas dot field */
  const canvas = $('#heroCanvas');
  if (canvas && !reduceMotion.matches) {
    const ctx = canvas.getContext('2d');
    let w = 0, h = 0, dpr = 1, dots = [], t = 0, canvasRaf = null, heroVisible = true;
    const resize = () => {
      dpr = Math.min(devicePixelRatio || 1, 2);
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      dots = [];
      const gap = innerWidth < 700 ? 44 : 52;
      for (let x = gap / 2; x < w; x += gap) for (let y = gap / 2; y < h; y += gap) dots.push({ x, y, ox: x, oy: y });
    };
    const draw = () => {
      if (!heroVisible) { canvasRaf = null; return; }
      t += 0.008;
      ctx.clearRect(0, 0, w, h);
      const rect = canvas.getBoundingClientRect();
      const px = mx - rect.left, py = my - rect.top;
      for (const d of dots) {
        const dist = Math.hypot(d.ox - px, d.oy - py);
        const force = Math.max(0, 1 - dist / 180);
        const ang = Math.atan2(d.oy - py, d.ox - px);
        const push = force * 22;
        const wave = Math.sin(t + d.ox * 0.01 + d.oy * 0.01) * 2;
        const x = d.ox + Math.cos(ang) * push;
        const y = d.oy + Math.sin(ang) * push + wave;
        const alpha = 0.10 + force * 0.5;
        ctx.beginPath();
        ctx.arc(x, y, 1.1 + force * 1.4, 0, Math.PI * 2);
        const light = root.dataset.theme === 'light';
        ctx.fillStyle = light ? `rgba(0,0,0,${alpha})` : `rgba(255,255,255,${alpha})`;
        ctx.fill();
      }
      canvasRaf = requestAnimationFrame(draw);
    };
    resize(); draw();
    addEventListener('resize', resize);
    if ('IntersectionObserver' in window) new IntersectionObserver(([en]) => { heroVisible = en.isIntersecting; if (heroVisible && !canvasRaf) draw(); }, { threshold: 0 }).observe(canvas);
  }

  /* hero interactive letters */
  const heroTitle = $('#heroTitle');
  if (heroTitle) {
    $$('.hero-line', heroTitle).forEach(line => {
      const text = line.dataset.text || line.textContent;
      line.textContent = '';
      [...text].forEach(ch => {
        const span = document.createElement('span');
        span.className = 'hero-char';
        span.textContent = ch === ' ' ? '\u00a0' : ch;
        line.appendChild(span);
      });
    });
    const chars = $$('.hero-char', heroTitle);
    if (finePointer.matches && !reduceMotion.matches) {
      heroTitle.addEventListener('pointermove', e => {
        chars.forEach(ch => {
          const r = ch.getBoundingClientRect();
          const dx = e.clientX - (r.left + r.width / 2);
          const dy = e.clientY - (r.top + r.height / 2);
          const d = Math.hypot(dx, dy);
          const f = Math.max(0, 1 - d / 240);
          ch.style.transform = `translateY(${-f * 26}px) skewX(${(dx / 40) * f}deg)`;
          ch.classList.toggle('it', f > 0.4);
        });
      });
      heroTitle.addEventListener('pointerleave', () => chars.forEach(ch => { ch.style.transform = ''; ch.classList.remove('it'); }));
    }
  }

  /* work list: filters, expandable rows, hover peek */
  const workRows = $$('.work-row');
  const filterBtns = $$('.filter-pill');
  const workPeek = $('#workPeek');
  const peekPatterns = [
    'repeating-linear-gradient(90deg,var(--text) 0 1px,transparent 1px 22px)',
    'radial-gradient(circle at 50% 50%,var(--text) 0 3px,transparent 4px) 0 0/18px 18px',
    'linear-gradient(135deg,var(--text) 50%,transparent 50%)'
  ];
  filterBtns.forEach(btn => btn.addEventListener('click', () => {
    const f = btn.dataset.filter;
    filterBtns.forEach(b => { const active = b === btn; b.classList.toggle('is-active', active); b.setAttribute('aria-pressed', String(active)); });
    workRows.forEach(row => { row.hidden = f !== 'all' && row.dataset.category !== f; if (!row.hidden) row.classList.add('is-visible'); });
  }));
  workRows.forEach(row => {
    const btn = $('.work-row-btn', row);
    btn.addEventListener('click', () => {
      const open = !row.classList.contains('open');
      workRows.forEach(r => { r.classList.remove('open'); $('.work-row-btn', r).setAttribute('aria-expanded', 'false'); });
      if (open) { row.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); }
    });
    if (workPeek && finePointer.matches) {
      btn.addEventListener('pointerenter', () => {
        workPeek.style.backgroundImage = peekPatterns[Number(row.dataset.case)] || peekPatterns[0];
        workPeek.classList.add('on');
      });
      btn.addEventListener('pointerleave', () => workPeek.classList.remove('on'));
    }
  });
  if (workPeek && finePointer.matches) {
    let px = 0, py = 0, tx = 0, ty = 0;
    addEventListener('pointermove', e => {
      tx = Math.max(150, Math.min(e.clientX + 210, innerWidth - 150));
      ty = Math.max(190, Math.min(e.clientY, innerHeight - 190));
    }, { passive: true });
    (function peekLoop(){ px += (tx - px) * 0.14; py += (ty - py) * 0.14; workPeek.style.left = px + 'px'; workPeek.style.top = py + 'px'; requestAnimationFrame(peekLoop); })();
  }

  /* skills accordion */
  $$('.skill').forEach(skill => {
    const btn = $('button', skill);
    btn.addEventListener('click', () => {
      const open = skill.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(open));
    });
  });

  /* copy shared email */
  const copyEmailBtn = $('#copyEmail');
  if (copyEmailBtn) copyEmailBtn.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText('artifactsite77@gmail.com'); showToast('Почта скопирована', 'success'); }
    catch { showToast('Не удалось скопировать. Адрес: artifactsite77@gmail.com', 'error'); }
  });

  /* team dialog */
  const members = [
    { name: 'Егор', initial: 'Е', lead: 'Егор — участник команды Nexa Code. Профиль скоро будет дополнен ролью, фокусом и ссылками.' },
    { name: 'Кирилл', initial: 'К', lead: 'Кирилл — участник команды Nexa Code. Профиль скоро будет дополнен ролью, фокусом и ссылками.' }
  ];
  const memberDialog = $('#memberDialog');
  const openMember = i => { const m = members[i]; $('#memberTitle').textContent = m.name; $('#memberAvatar').textContent = m.initial; $('#memberLead').textContent = m.lead; memberDialog.showModal(); syncModalState(); };
  $$('.team-card').forEach(card => {
    card.addEventListener('click', () => openMember(Number(card.dataset.member)));
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openMember(Number(card.dataset.member)); } });
  });

  /* process carousel */
  const track = $('#processTrack');
  const processBar = $('#processBar');
  const step = dir => { const card = $('.process-card', track); const amount = card ? card.getBoundingClientRect().width + 18 : 320; track.scrollBy({ left: dir * amount, behavior: reduceMotion.matches ? 'auto' : 'smooth' }); };
  $('#processPrev').addEventListener('click', () => step(-1));
  $('#processNext').addEventListener('click', () => step(1));
  const updateProcess = () => { const max = track.scrollWidth - track.clientWidth; const pct = max > 0 ? 25 + (track.scrollLeft / max) * 75 : 100; processBar.style.width = `${pct}%`; };
  track.addEventListener('scroll', updateProcess, { passive: true }); addEventListener('resize', updateProcess); updateProcess();
  track.addEventListener('keydown', e => { if (e.key === 'ArrowRight') { e.preventDefault(); step(1); } if (e.key === 'ArrowLeft') { e.preventDefault(); step(-1); } });

  /* dialogs */
  const syncModalState = () => body.classList.toggle('modal-open', !!$('dialog[open]'));
  $$('dialog').forEach(dialog => {
    dialog.addEventListener('close', syncModalState);
    dialog.addEventListener('click', e => { if (e.target !== dialog) return; const r = dialog.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close(); });
  });
  $$('[data-close-dialog]').forEach(btn => btn.addEventListener('click', () => btn.closest('dialog').close()));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { setMenu(false); setEffectsPanel(false); } });

  /* toast */
  const toast = $('#toast'); let toastTimer;
  const toastIcons = { success: '#i-check', error: '#i-alert', info: '#i-alert' };
  const showToast = (text, kind = 'info') => {
    toast.className = `toast is-visible is-${kind}`;
    toast.innerHTML = `<svg class="icon" aria-hidden="true"><use href="${toastIcons[kind] || toastIcons.info}"/></svg><span></span>`;
    $('span', toast).textContent = text;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 3200);
  };

  /* privacy policy dialog */
  const privacyDialog = $('#privacyDialog');
  const openPrivacy = () => { if (!privacyDialog) return; privacyDialog.showModal(); syncModalState(); };
  $$('[data-open-privacy]').forEach(btn => btn.addEventListener('click', e => { e.preventDefault(); openPrivacy(); }));
  if (location.hash === '#privacy') openPrivacy();

  /* contact form -> shared team email via Airform */
  const CONTACT_EMAIL = 'artifactsite77@gmail.com';
  const CONTACT_ENDPOINT = `https://airform.io/${CONTACT_EMAIL}`;
  const contactForm = $('#contactForm');
  const contactStatus = $('#contactStatus');
  const contactSubmit = $('#contactSubmit');

  const fields = {
    name: { input: $('#contactName'), error: $('#contactNameError'), validate: v => v.trim() ? '' : 'Напишите, пожалуйста, имя' },
    email: { input: $('#contactEmail'), error: $('#contactEmailError'), validate: v => !v.trim() ? 'Укажите почту для ответа' : (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? '' : 'Похоже, в адресе почты ошибка') },
    message: { input: $('#contactMessage'), error: $('#contactMessageError'), validate: v => v.trim() ? '' : 'Добавьте сообщение' },
    consent: { input: $('#contactConsent'), error: $('#contactConsentError'), validate: () => $('#contactConsent').checked ? '' : 'Подтвердите согласие на обработку данных' }
  };
  const setFieldError = (key, msg) => {
    const f = fields[key];
    const wrap = f.input.closest('.field') || f.input.closest('.consent-block');
    f.error.hidden = !msg;
    $('span', f.error).textContent = msg || '';
    f.input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    if (wrap) wrap.classList.toggle('has-error', !!msg);
  };
  const clearFieldErrors = () => Object.keys(fields).forEach(k => setFieldError(k, ''));
  Object.entries(fields).forEach(([key, f]) => {
    const evt = f.input.type === 'checkbox' ? 'change' : 'input';
    f.input.addEventListener(evt, () => setFieldError(key, ''));
  });

  const statusIcons = { pending: '#i-clock', success: '#i-check', error: '#i-alert', warning: '#i-alert' };
  const setStatus = (kind, title, text, actions = []) => {
    contactStatus.hidden = false;
    contactStatus.className = `form-status is-${kind}`;
    contactStatus.innerHTML = `<span class="form-status-icon" aria-hidden="true"><svg class="icon"><use href="${statusIcons[kind] || statusIcons.error}"/></svg></span><div class="form-status-body"><p class="form-status-title"></p><p class="form-status-text"></p><div class="form-status-actions" hidden></div></div>`;
    $('.form-status-title', contactStatus).textContent = title;
    $('.form-status-text', contactStatus).textContent = text;
    const actionsWrap = $('.form-status-actions', contactStatus);
    if (actions.length) {
      actionsWrap.hidden = false;
      actions.forEach(a => {
        const el = document.createElement(a.href ? 'a' : 'button');
        el.className = `status-action${a.primary ? ' status-action-primary' : ''}`;
        el.textContent = a.label;
        if (a.href) { el.href = a.href; }
        else { el.type = 'button'; el.addEventListener('click', a.onClick); }
        actionsWrap.appendChild(el);
      });
    }
  };
  const mailtoAction = { label: 'Написать напрямую', href: `mailto:${CONTACT_EMAIL}` };
  const retryAction = { label: 'Повторить отправку', primary: true, onClick: () => contactForm.requestSubmit() };

  const setSubmitting = (busy) => {
    contactSubmit.disabled = busy;
    contactSubmit.setAttribute('aria-busy', String(busy));
    contactSubmit.innerHTML = busy
      ? 'Отправляем…'
      : 'Отправить на почту <svg class="icon"><use href="#i-arrow"/></svg>';
  };

  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFieldErrors();
    const name = fields.name.input.value.trim();
    const email = fields.email.input.value.trim();
    const message = fields.message.input.value.trim();
    let firstInvalid = null;
    const values = { name, email, message, consent: '' };
    Object.keys(fields).forEach(key => {
      const msg = fields[key].validate(values[key]);
      if (msg) { setFieldError(key, msg); if (!firstInvalid) firstInvalid = fields[key].input; }
    });
    if (firstInvalid) {
      setStatus('error', 'Проверьте форму', 'Мы подсветили поля, которые нужно исправить. После этого отправьте сообщение ещё раз.');
      firstInvalid.focus();
      return;
    }
    if (contactForm.elements.website && contactForm.elements.website.value) return; // honeypot
    if (!navigator.onLine) {
      setStatus('error', 'Нет подключения', 'Похоже, браузер не в сети. Проверьте интернет и повторите отправку или напишите напрямую на общую почту.', [retryAction, mailtoAction]);
      showToast('Нет подключения к интернету', 'error');
      return;
    }

    const data = new FormData(contactForm);
    data.set('name', name);
    data.set('email', email);
    data.set('message', message);
    data.set('subject', `Nexa Code — сообщение от ${name}`);
    data.set('replyto', email);
    data.set('page', location.href);

    setSubmitting(true);
    setStatus('pending', 'Отправляем', 'Сообщение уходит на общую почту команды…');
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 20000);
      const res = await fetch(CONTACT_ENDPOINT, {
        method: 'POST',
        body: data,
        headers: { Accept: 'text/html, application/json;q=0.9' },
        signal: controller.signal
      });
      clearTimeout(timer);
      const text = await res.text();
      const needsVerification = /email verification|confirm your email|подтвердите/i.test(text);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      if (needsVerification) {
        setStatus('warning', 'Нужно подтверждение', `Airform запросил подтверждение почты для этого домена. Письмо отправлено на ${CONTACT_EMAIL}. Откройте его, подтвердите адрес и повторите отправку. Можно также написать напрямую.`, [mailtoAction]);
        showToast('Требуется подтверждение домена', 'info');
        return;
      }
      contactForm.reset();
      clearFieldErrors();
      setStatus('success', 'Отправлено', `Готово: сообщение отправлено на ${CONTACT_EMAIL}. Ответим на указанную вами почту.`);
      showToast('Сообщение отправлено команде', 'success');
    } catch (err) {
      const aborted = err && err.name === 'AbortError';
      const title = aborted ? 'Сервис не ответил' : 'Не удалось отправить';
      const text = aborted
        ? `Сервис отправки не ответил вовремя. Повторите попытку или напишите напрямую: ${CONTACT_EMAIL}.`
        : `Автоотправка временно недоступна. Повторите попытку или напишите напрямую: ${CONTACT_EMAIL}.`;
      setStatus('error', title, text, [retryAction, mailtoAction]);
      showToast('Не удалось отправить сообщение', 'error');
    } finally {
      setSubmitting(false);
    }
  });
})();
